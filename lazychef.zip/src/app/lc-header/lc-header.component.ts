import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-header',
  templateUrl: './lc-header.component.html',
  styleUrls: ['./lc-header.component.css']
})
export class LcHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
