import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-footer',
  templateUrl: './lc-footer.component.html',
  styleUrls: ['./lc-footer.component.css']
})
export class LcFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
