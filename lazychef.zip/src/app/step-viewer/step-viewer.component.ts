import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'step-viewer',
  templateUrl: './step-viewer.component.html',
  styleUrls: ['./step-viewer.component.css']
})
export class StepViewerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
