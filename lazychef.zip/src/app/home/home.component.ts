import { RecipesService } from './../services/recipes.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

}
