import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'recipe-search',
  templateUrl: './recipe-search.component.html',
  styleUrls: ['./recipe-search.component.css']
})
export class RecipeSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
